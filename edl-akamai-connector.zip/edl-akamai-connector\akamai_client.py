"""Akamai Client Lists API client (standard library only).

Signs requests with the hand-rolled EdgeGrid signer (edgegrid_auth) over
urllib.request, so no third-party packages are needed on the host.

Client Lists API (base /client-list/v1):
  GET  /lists/{listId}?includeItems=true          -> read items
  POST /lists/{listId}/items  {append:[], delete:[]} -> add/remove items
  POST /lists/{listId}/activations {action,network,comments} -> activate

Endpoints/params were taken from Akamai's official Go SDK (pkg/clientlists) and
techdocs. accountSwitchKey is Akamai's standard cross-account query parameter;
confirm it is honoured on your contract before first multi-tenant production use.
"""
from __future__ import annotations

import configparser
import json
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Iterable, Set
from urllib.parse import urlencode

import edgegrid_auth

_RETRYABLE = {429, 500, 502, 503, 504}


class AkamaiError(Exception):
    pass


def build_ssl_context(ca_bundle: str = "", verify_ssl: bool = True) -> ssl.SSLContext:
    """Build the TLS context for the Akamai connection.

    Default: verify against the system trust store. On Windows this includes the
    machine certificate store, so a corporate TLS-inspection proxy's root CA that
    IT has pushed (e.g. via GPO) is already trusted -- no bypass needed.

    ``ca_bundle``: additionally trust a corporate root CA from a PEM file while
    keeping verification fully on (the recommended fix when the root is not in
    the system store). It is ADDED to the defaults, so public roots still work.

    ``verify_ssl=False``: disable verification entirely. Last resort only -- it
    exposes the API tokens and, because EdgeGrid signs only requests (not
    responses), lets any on-path interceptor forge or tamper with responses.
    """
    context = ssl.create_default_context()
    if not verify_ssl:
        context.check_hostname = False       # must precede CERT_NONE or it raises
        context.verify_mode = ssl.CERT_NONE
        return context
    if ca_bundle:
        context.load_verify_locations(cafile=ca_bundle)
    return context


def _normalize_proxy(proxy: str) -> str:
    """Accept '172.21.177.163:8080' or 'http://host:port'; default scheme http."""
    proxy = (proxy or "").strip()
    if proxy and "://" not in proxy:
        proxy = "http://" + proxy
    return proxy


def _build_opener(ssl_context, proxy: str = ""):
    """Opener that carries the TLS context and, if set, an explicit egress proxy.

    An empty proxy falls back to urllib's default (HTTPS_PROXY/HTTP_PROXY env
    vars, or the Windows registry) so behaviour is unchanged when unconfigured.
    """
    proxy = _normalize_proxy(proxy)
    if proxy:
        proxy_handler = urllib.request.ProxyHandler({"http": proxy, "https": proxy})
    else:
        proxy_handler = urllib.request.ProxyHandler()  # default: env / registry
    https_handler = urllib.request.HTTPSHandler(context=ssl_context)
    return urllib.request.build_opener(proxy_handler, https_handler)


def load_edgerc(path: str = "~/.edgerc", section: str = "default") -> dict:
    """Read EdgeGrid credentials from an .edgerc section."""
    parser = configparser.ConfigParser()
    read = parser.read(Path(path).expanduser())
    if not read:
        raise AkamaiError(f".edgerc not found at {path}")
    if not parser.has_section(section):
        raise AkamaiError(f".edgerc section [{section}] not found in {path}")

    def get(key: str) -> str:
        return parser.get(section, key, fallback="").strip()

    creds = {
        "host": get("host").replace("https://", "").replace("http://", "").strip("/"),
        "client_token": get("client_token"),
        "client_secret": get("client_secret"),
        "access_token": get("access_token"),
    }
    missing = [k for k, v in creds.items() if not v]
    if missing:
        raise AkamaiError(f".edgerc [{section}] is missing: {', '.join(missing)}")
    max_body = get("max-body") or get("max_body")
    creds["max_body"] = int(max_body) if max_body else edgegrid_auth.DEFAULT_MAX_BODY
    # Optional account switch key (MSSP multi-tenant), read from whatever spelling
    # the .edgerc uses. configparser lowercases option names, so we normalise each
    # option (drop separators, lowercase) and accept accountSwitchKey / account_key /
    # account-switch-key / etc. Empty => operate on the account this credential is
    # natively scoped to.
    creds["account_switch_key"] = ""
    for opt in parser.options(section):
        if opt.replace("_", "").replace("-", "").lower() in ("accountswitchkey", "accountkey"):
            val = parser.get(section, opt, fallback="").strip()
            if val:
                creds["account_switch_key"] = val
                break
    return creds


class ClientListsClient:
    def __init__(self, credentials: dict, retries: int = 3, timeout: int = 60,
                 ca_bundle: str = "", verify_ssl: bool = True, proxy: str = ""):
        self.creds = credentials
        self.host = credentials["host"]
        self.account_switch_key = credentials.get("account_switch_key", "")
        self.retries = retries
        self.timeout = timeout
        self._ssl_context = build_ssl_context(ca_bundle, verify_ssl)
        self._opener = _build_opener(self._ssl_context, proxy)
        if not verify_ssl:
            print("[SECURITY WARNING] Akamai TLS certificate verification is DISABLED "
                  "(akamai_verify_ssl=false). API tokens and responses are exposed to any "
                  "on-path interceptor. Prefer 'akamai_ca_bundle' with your corporate root CA.",
                  file=sys.stderr)

    def _request(self, method: str, path: str, query=None, payload=None, account_switch_key: str = ""):
        params = dict(query or {})
        ask = account_switch_key or self.account_switch_key
        if ask:
            params["accountSwitchKey"] = ask
        url = f"https://{self.host}{path}"
        if params:
            url += "?" + urlencode(params)

        body = b""
        headers = {"Accept": "application/json"}
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        headers["Authorization"] = edgegrid_auth.sign(
            method, url, body=body, max_body=self.creds["max_body"],
            client_token=self.creds["client_token"],
            client_secret=self.creds["client_secret"],
            access_token=self.creds["access_token"],
        )
        request = urllib.request.Request(url, data=body or None, headers=headers, method=method)

        last_error = None
        for attempt in range(self.retries):
            try:
                with self._opener.open(request, timeout=self.timeout) as response:  # noqa: S310
                    raw = response.read().decode("utf-8", "replace")
                    return json.loads(raw) if raw.strip() else {}
            except urllib.error.HTTPError as exc:
                if exc.code in _RETRYABLE and attempt < self.retries - 1:
                    last_error = exc
                    time.sleep(2 ** attempt)
                    continue
                detail = exc.read().decode("utf-8", "replace")[:500]
                raise AkamaiError(f"{method} {path} -> HTTP {exc.code}: {detail}") from exc
            except urllib.error.URLError as exc:
                reason = str(getattr(exc, "reason", exc))
                if "CERTIFICATE_VERIFY" in reason.upper():
                    # Not retryable, and the fix is a config choice: say exactly what to do.
                    raise AkamaiError(
                        f"{method} {path} -> TLS certificate verification failed ({reason}). "
                        "A corporate TLS-inspection proxy is the usual cause. Fix options: point "
                        "'akamai_ca_bundle' at the proxy's root CA PEM (keeps verification ON, "
                        "recommended), or bypass with --insecure / \"akamai_verify_ssl\": false."
                    ) from exc
                if attempt < self.retries - 1:
                    last_error = exc
                    time.sleep(2 ** attempt)
                    continue
                raise AkamaiError(f"{method} {path} -> {exc}") from exc
        raise AkamaiError(f"{method} {path} failed after {self.retries} attempts: {last_error}")

    def find_list_id_by_name(self, name: str, list_type: str = "IP",
                             account_switch_key: str = "") -> str:
        """Resolve an EXISTING Client List's id from its exact name.

        This never creates a list. It raises if there is no match (the list must
        be created in Control Center first) or if more than one list shares the
        name (ambiguous -- use an explicit client_list_id).
        """
        data = self._request(
            "GET", "/client-list/v1/lists",
            query={"type": list_type, "name": name},
            account_switch_key=account_switch_key,
        )
        matches = [item for item in data.get("content", [])
                   if item.get("name") == name and item.get("type") == list_type]
        if not matches:
            raise AkamaiError(
                f"No existing {list_type} Client List named {name!r} was found in this account. "
                "This tool never creates lists -- create it in Control Center first, "
                "or set 'client_list_id' explicitly."
            )
        if len(matches) > 1:
            ids = ", ".join(sorted(str(m.get("listId", "?")) for m in matches))
            raise AkamaiError(
                f"Multiple {list_type} Client Lists are named {name!r} (ids: {ids}). "
                "Set an explicit 'client_list_id' to disambiguate."
            )
        return matches[0]["listId"]

    def get_list_items(self, list_id: str, account_switch_key: str = "") -> Set[str]:
        data = self._request(
            "GET", f"/client-list/v1/lists/{list_id}",
            query={"includeItems": "true"}, account_switch_key=account_switch_key,
        )
        return {item["value"] for item in data.get("items", []) if item.get("value")}

    def update_items(self, list_id: str, add: Iterable[str], remove: Iterable[str],
                     account_switch_key: str = "") -> None:
        payload = {
            "append": [{"value": v} for v in sorted(add)],
            "delete": [{"value": v} for v in sorted(remove)],
        }
        if not payload["append"] and not payload["delete"]:
            return
        self._request(
            "POST", f"/client-list/v1/lists/{list_id}/items",
            payload=payload, account_switch_key=account_switch_key,
        )

    def activate(self, list_id: str, network: str, comments: str,
                 account_switch_key: str = "") -> None:
        self._request(
            "POST", f"/client-list/v1/lists/{list_id}/activations",
            payload={"action": "ACTIVATE", "network": network, "comments": comments},
            account_switch_key=account_switch_key,
        )
