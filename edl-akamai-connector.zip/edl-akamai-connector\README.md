# EDL → Akamai Client List Connector

Pushes the EDL IOC Manager's **IP** blocklist into an Akamai **Client List**, per
tenant, so **App & API Protector (AAP/ASM)** enforces it with a DENY. Standard
library only — it runs on the same host as the EDL IOC Manager and adds no
dependencies to it.

## Why a connector (and not a "fetch")

A Palo Alto firewall consumes an External Dynamic List by **pulling** a text URL
on a schedule. **Akamai has no equivalent** — every path for customer IOCs is a
**push** (portal, CSV, or API). So this connector inverts the direction: it reads
the published `Block_IOC_IPs.txt` and pushes the entries into Akamai on a schedule.

## Scope (important)

| EDL file | Akamai home | In this connector? |
|---|---|---|
| `Block_IOC_IPs.txt` (IPs / CIDR) | **Client List** (type IP), referenced by the AAP policy with a DENY action | **Yes** |
| `Block_IOC_URLs.txt` (domains / URLs) | **None** — Client Lists hold IP/CIDR/ASN/Geo/TLS only | **No — out of scope** |

Domain/URL IOCs cannot be enforced in AAP; they are a forward-proxy/DNS concern
(Akamai SIA), which this client does not use. This is a documented coverage gap,
not a silent one.

## How it works

For each tenant: **read → parse → diff → push → activate**.

1. **Read** `Block_IOC_IPs.txt` from `EDL_DATA_DIR` on disk (the connector is
   co-located with the EDL host). A URL source is an optional fallback.
2. **Parse** the same way the manager does: skip blanks and `#` comment lines,
   take the first whitespace token of each line (dropping the `#TICKET #DATE`
   comment). Keep only valid IP/CIDR; drop anything else.
3. **Diff** against the current Client List (read-only GET).
4. **Push** the add/remove delta, then **activate** the new list version.
5. **Fail-safe**: if the source is missing, empty, or shrinks beyond
   `safety_shrink_pct` vs the live list, the tenant is **aborted, not wiped** —
   a broken read never silently drops protection. The process exits non-zero so
   your scheduler alerts.

## Files

| File | Purpose | Deps |
|---|---|---|
| `edgegrid_auth.py` | Hand-rolled EdgeGrid EG1-HMAC-SHA256 request signer | stdlib |
| `akamai_client.py` | Client Lists API client (urllib + the signer) | stdlib |
| `edl_source.py` | Read + parse the IP blocklist | stdlib |
| `iocdiff.py` | Diff + fail-safe logic | stdlib |
| `connector.py` | Orchestration + CLI | stdlib |
| `config.example.json` | Per-tenant configuration template | — |
| `tests/` | Unit tests (EdgeGrid vectors, parse, diff, fail-safe, run) | stdlib |

## Configure — tenants are folders under `Client/`

Tenants are **discovered from the filesystem**, not listed in JSON. Create a
`Client/` folder next to `connector.py`; each subfolder is one managed customer
(the folder name is the tenant name):

```
edl-akamai-connector/
  connector.py
  .edgerc                 <- DEFAULT credential (fallback)
  Client/
    CustomerA/.edgerc     <- CustomerA's own credential
    CustomerB/            <- no .edgerc -> uses the default above
    CustomerC/.edgerc
```

- **Credential per tenant:** `Client/<tenant>/.edgerc` if present, otherwise the
  `.edgerc` beside `Client/`. Each `.edgerc` is a full EdgeGrid credential; put the
  **`account_switch_key` on its last line** (`account_switch_key = 1-ABC:1-XYZ`).
  A credential with no switch key operates on the account it is natively scoped to.
- **Onboard a customer:** create `Client/<name>/`, drop in their `.edgerc`. Done.
- **Opt a customer out:** remove or rename their folder.
- **Fixed target list:** every tenant pushes into the Client List named
  **`Singtel_IOC_List`** (set once via `client_list_name`, default is that name).
  It must **already exist** in each account — this tool **never creates lists**.

Create the `.edgerc`(s) in Control Center → Identity & Access Management; grant the
**Client Lists** API **READ-WRITE**. Account switching needs a normal managed API
client (not a service-account client). `config.json` now holds only global settings
(`central_ioc_source`, `client_list_name`, `activation_network`, `safety_shrink_pct`,
TLS options); see `config.example.json`.

## TLS to Akamai (corporate proxies)

Because this connector is **standard-library only**, Python's `ssl` uses the
**system trust store** — on Windows that includes the machine certificate store,
where a corporate TLS-inspection proxy's root CA (pushed by GPO) already lives.
So unlike `requests`/`certifi`-based tooling, it should connect with verification
**on** and need no bypass. Two config options cover the exceptions:

- `akamai_ca_bundle` — path to a PEM containing your corporate proxy's root CA.
  Use this if you hit `CERTIFICATE_VERIFY_FAILED` (the root isn't in the store
  the run-as account sees). The CA is **added** to the defaults, so verification
  stays fully on. This is the recommended fix.
- `akamai_verify_ssl` — defaults to `true`. Set it to `false` (or run with
  `--insecure` for a one-off) to disable verification entirely — the stdlib
  equivalent of `requests`' `verify=False`. It prints a `[SECURITY WARNING]` on
  every run. Reserve it for when the CA-bundle route isn't possible: EdgeGrid
  signs only *requests*, so with verification off an interceptor can capture your
  API tokens and forge/tamper with *responses* (e.g. falsify a list's contents) —
  a real risk for automation that writes enforcement data. Prefer `akamai_ca_bundle`.
  If a fetch fails with `CERTIFICATE_VERIFY_FAILED`, the error message tells you
  exactly which option to set.

### Egress proxy

If the host reaches Akamai through a forwarding proxy, set it in `config.json`
(editable, no code change):

```json
"akamai_proxy": "172.21.177.163:8080"
```

A bare `host:port` is assumed `http://`. It applies to the Akamai API calls
(HTTPS via CONNECT). Leave it `""` to fall back to urllib's default behaviour
(`HTTPS_PROXY`/`HTTP_PROXY` env vars, or the Windows registry). This is the
*forwarding* proxy; a *TLS-inspection* proxy that re-signs certificates is a
separate concern handled by `akamai_ca_bundle`.

## Run

```
python connector.py --config config.json --offline    # no Akamai calls (local check)
python connector.py --config config.json --dry-run     # read-only: show the real diff
python connector.py --config config.json               # live: push + activate
python connector.py --config config.json --tenant CustomerA
```

Schedule the live command via Windows Task Scheduler on the EDL host. A non-zero
exit means at least one tenant aborted or errored.

## Logging

Every run writes to `logs/connector.log` (override the folder with `log_dir` in
the config). The file **rotates daily and keeps 10 days** (`connector.log`,
`connector.log.2026-07-12`, …), then old days are deleted automatically — no
cleanup job needed. Every line is **tagged with the client name**, so each
customer's activity is fully traceable:

```
2026-07-13 03:00:01 INFO    [-]         run start: 3 tenant(s) under Client/, list=Singtel_IOC_List, ...
2026-07-13 03:00:03 INFO    [CustomerA] pushed: credential=own desired=3611 current=3590 add=30 remove=9 list_id=98765_... :: applied
2026-07-13 03:00:04 WARNING [CustomerB] aborted: ... :: source shrank 44% (limit 30%)
2026-07-13 03:00:05 ERROR   [CustomerC] error: AkamaiError: GET /client-list/v1/lists -> HTTP 401 ...
2026-07-13 03:00:05 INFO    [-]         run complete: 3 processed, 2 failure(s)
```

The `[-]` tag marks run-level (non-client) lines. Console output is unchanged;
the log file is the durable, per-client audit trail. `grep "\[CustomerA\]"` gives
one customer's full history within the retained window.

## Host placement and hygiene (co-located on the EDL IIS server)

- Put this folder and `.edgerc` **outside any IIS-served web root** (e.g.
  `C:\Tools\edl-akamai-connector`) so neither the source nor the credentials are
  web-downloadable.
- Restrict the `.edgerc` ACL to Administrators, SYSTEM, and the scheduled-task
  identity — the same discipline as the EDL LDAP bind password.
- The scheduled-task identity needs read on `EDL_DATA_DIR` and `.edgerc`; the
  host needs outbound HTTPS egress to Akamai.

## Verification status

- **Verified here:** the EdgeGrid signer reproduces Akamai's official reference
  test vectors exactly; parse (comment stripping, IP/CIDR-only filtering,
  de-dupe); diff; fail-safe (empty + excessive-shrink); and the push/activate
  call sequence against a fake client. All unit tests pass. An `--offline` run
  against the real blocklist computes the correct initial-load diff.
- **NOT verified (no tenant available):** the live Akamai API calls. Run
  `--dry-run`, then activate to **STAGING** against one non-production account,
  confirm a test IP is blocked, then promote to production.

## Confirm before production use

- Exact Client Lists API endpoints/version and that `accountSwitchKey` is honoured
  on your contract (taken from Akamai's official Go SDK + techdocs).
- Each account's **`Singtel_IOC_List`** must **already exist** and be **referenced
  in the AAP policy with a DENY action** — otherwise the list blocks nothing. The
  connector resolves it by name at run time (never creates it).
- Decide the activation network and any change-control/approval step.

## Not in scope

No changes to the EDL IOC Manager (this connector only reads its output file).
Provisioning the Client Lists and wiring the DENY policy is a one-time, per-account
setup. Domain/URL IOCs have no Client List home (see Scope).
