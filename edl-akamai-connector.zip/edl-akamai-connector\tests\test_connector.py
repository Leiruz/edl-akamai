"""Unit tests for the EDL -> Akamai Client List connector core.

Standard library only; no Akamai credentials or network access. The live push
path is exercised with a fake client injected via client_factory.
"""
import ssl
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import akamai_client
import connector
import edl_source
import iocdiff


class TestSSLContext(unittest.TestCase):
    def test_default_verifies(self):
        ctx = akamai_client.build_ssl_context()
        self.assertTrue(ctx.check_hostname)
        self.assertEqual(ctx.verify_mode, ssl.CERT_REQUIRED)

    def test_ca_bundle_keeps_verification_on(self):
        ctx = akamai_client.build_ssl_context(ca_bundle="", verify_ssl=True)
        self.assertTrue(ctx.check_hostname)
        self.assertEqual(ctx.verify_mode, ssl.CERT_REQUIRED)

    def test_bypass_disables_verification(self):
        ctx = akamai_client.build_ssl_context(verify_ssl=False)
        self.assertFalse(ctx.check_hostname)
        self.assertEqual(ctx.verify_mode, ssl.CERT_NONE)


class TestParse(unittest.TestCase):
    def test_keeps_ips_and_cidr_drops_the_rest(self):
        text = (
            "185.12.59.117 #CSTASK0012841 #2026-06-04\n"
            "# a whole-line comment\n"
            "\n"
            "   \n"
            "10.0.0.0/24 #CSTASK0002 #2026-06-04\n"
            "2001:db8::1 #CSTASK0003\n"
            "evil.example.com #CSTASK0004\n"   # domain -> dropped (not a Client List IP)
            "1.2.3.4/path #CSTASK0005\n"        # IP-with-path -> dropped
        )
        self.assertEqual(
            edl_source.parse_ip_lines(text.splitlines()),
            {"185.12.59.117", "10.0.0.0/24", "2001:db8::1"},
        )

    def test_dedupes(self):
        self.assertEqual(edl_source.parse_ip_lines(["1.1.1.1 #x", "1.1.1.1 #y"]), {"1.1.1.1"})


class TestDiff(unittest.TestCase):
    def test_add_and_remove(self):
        d = iocdiff.compute_diff({"a", "b", "c"}, {"b", "c", "d"})
        self.assertEqual(d.add, {"a"})
        self.assertEqual(d.remove, {"d"})
        self.assertTrue(d.changed)

    def test_no_change(self):
        self.assertFalse(iocdiff.compute_diff({"a"}, {"a"}).changed)


class TestFailSafe(unittest.TestCase):
    def test_empty_source_aborts(self):
        ok, _ = iocdiff.fail_safe(set(), {"a", "b"}, 30)
        self.assertFalse(ok)

    def test_empty_current_allowed(self):
        ok, _ = iocdiff.fail_safe({"a"}, set(), 30)
        self.assertTrue(ok)

    def test_excessive_shrink_aborts(self):
        current = {str(i) for i in range(100)}
        desired = {str(i) for i in range(50)}  # 50% shrink > 30% limit
        ok, _ = iocdiff.fail_safe(desired, current, 30)
        self.assertFalse(ok)

    def test_small_shrink_allowed(self):
        current = {str(i) for i in range(100)}
        desired = {str(i) for i in range(80)}  # 20% shrink <= 30% limit
        ok, _ = iocdiff.fail_safe(desired, current, 30)
        self.assertTrue(ok)


class FakeClient:
    """Records calls instead of hitting Akamai."""

    def __init__(self, current=None):
        self._current = set(current or [])
        self.calls = []

    def find_list_id_by_name(self, name, list_type="IP", account_switch_key=""):
        self.calls.append(("resolve", name))
        return "RESOLVED:" + name

    def get_list_items(self, list_id, account_switch_key=""):
        return set(self._current)

    def update_items(self, list_id, add, remove, account_switch_key=""):
        self.calls.append(("update", list_id, set(add), set(remove)))

    def activate(self, list_id, network, comments, account_switch_key=""):
        self.calls.append(("activate", list_id, network))


def _config(tmp, ip_lines):
    ip_file = tmp / "ips.txt"
    ip_file.write_text(ip_lines, encoding="utf-8")
    return {
        "tenants": [{
            "name": "T1",
            "account_switch_key": "ask1",
            "edl_ip_path": str(ip_file),
            "client_list_id": "CL1",
            "activation_network": "STAGING",
            "safety_shrink_pct": 30,
        }]
    }


class TestRun(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def test_offline_shows_diff_no_writes(self):
        cfg = _config(self.tmp, "1.1.1.1 #t\n2.2.2.2 #t\n")
        results = connector.run(cfg, offline=True)
        self.assertEqual(results[0]["action"], "offline")
        self.assertEqual((results[0]["desired"], results[0]["add"]), (2, 2))  # vs assumed-empty

    def test_live_push_applies_diff_and_activates(self):
        cfg = _config(self.tmp, "1.1.1.1 #t\n2.2.2.2 #t\n")
        fake = FakeClient(current={"2.2.2.2", "9.9.9.9"})
        connector.run(cfg, client_factory=lambda c: fake)
        self.assertIn(("update", "CL1", {"1.1.1.1"}, {"9.9.9.9"}), fake.calls)
        self.assertIn(("activate", "CL1", "STAGING"), fake.calls)

    def test_failsafe_aborts_and_does_not_push(self):
        cfg = _config(self.tmp, "1.1.1.1 #t\n")  # 1 desired
        fake = FakeClient(current={f"9.9.9.{i}" for i in range(100)})  # vs 100 current -> huge shrink
        results = connector.run(cfg, client_factory=lambda c: fake)
        self.assertEqual(results[0]["action"], "aborted")
        self.assertEqual(fake.calls, [])


class TestSubscription(unittest.TestCase):
    """Central IOC list with per-tenant opt-in/out and easy onboarding."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.central = self.tmp / "central.txt"
        self.central.write_text("1.1.1.1 #t\n2.2.2.2 #t\n3.3.3.3 #t\n", encoding="utf-8")

    def _cfg(self, tenants):
        return {"central_ioc_source": str(self.central), "tenants": tenants}

    def test_disabled_tenant_is_skipped_no_calls(self):
        cfg = self._cfg([{"name": "B", "enabled": False, "client_list_id": "CLB"}])
        fake = FakeClient()
        results = connector.run(cfg, client_factory=lambda c: fake)
        self.assertEqual(results[0]["action"], "skipped")
        self.assertEqual(fake.calls, [])

    def test_enabled_tenant_inherits_central_source(self):
        cfg = self._cfg([{"name": "A", "account_switch_key": "a", "client_list_id": "CLA"}])
        results = connector.run(cfg, offline=True)
        self.assertEqual(results[0]["action"], "offline")
        self.assertEqual(results[0]["desired"], 3)  # the 3 central IPs

    def test_missing_enabled_key_defaults_to_subscribed(self):
        cfg = self._cfg([{"name": "A", "account_switch_key": "a", "client_list_id": "CLA"}])
        results = connector.run(cfg, offline=True)
        self.assertNotEqual(results[0]["action"], "skipped")

    def test_per_tenant_source_overrides_central(self):
        own = self.tmp / "own.txt"
        own.write_text("9.9.9.9 #t\n", encoding="utf-8")
        cfg = self._cfg([{"name": "A", "account_switch_key": "a", "client_list_id": "CLA",
                          "edl_ip_path": str(own)}])
        results = connector.run(cfg, offline=True)
        self.assertEqual(results[0]["desired"], 1)  # own feed, not the central 3

    def test_resolves_client_list_by_name_then_pushes(self):
        cfg = self._cfg([{"name": "T", "account_switch_key": "a",
                          "client_list_name": "Ben's IP Blacklist"}])
        fake = FakeClient()  # empty current list
        connector.run(cfg, client_factory=lambda c: fake)
        self.assertIn(("resolve", "Ben's IP Blacklist"), fake.calls)
        # pushed the central IPs to the resolved id, then activated
        self.assertTrue(any(c[0] == "update" and c[1] == "RESOLVED:Ben's IP Blacklist"
                            for c in fake.calls))
        self.assertTrue(any(c[0] == "activate" and c[1] == "RESOLVED:Ben's IP Blacklist"
                            for c in fake.calls))


class TestListNameResolution(unittest.TestCase):
    """akamai_client.find_list_id_by_name must exact-match and NEVER create."""

    def _client_returning(self, content):
        c = akamai_client.ClientListsClient(
            {"host": "h", "client_token": "a", "client_secret": "b",
             "access_token": "c", "max_body": 131072})
        c._request = lambda *a, **k: {"content": content}
        return c

    def test_exact_match_returns_id(self):
        c = self._client_returning([
            {"name": "Ben's IP Blacklist", "type": "IP", "listId": "999_BEN"},
            {"name": "Other", "type": "IP", "listId": "111"},
        ])
        self.assertEqual(c.find_list_id_by_name("Ben's IP Blacklist"), "999_BEN")

    def test_no_match_raises_and_never_creates(self):
        c = self._client_returning([{"name": "Other", "type": "IP", "listId": "111"}])
        with self.assertRaises(akamai_client.AkamaiError):
            c.find_list_id_by_name("Ben's IP Blacklist")

    def test_multiple_match_raises(self):
        c = self._client_returning([
            {"name": "Dup", "type": "IP", "listId": "1"},
            {"name": "Dup", "type": "IP", "listId": "2"},
        ])
        with self.assertRaises(akamai_client.AkamaiError):
            c.find_list_id_by_name("Dup")

    def test_wrong_type_is_not_matched(self):
        c = self._client_returning([{"name": "Ben's IP Blacklist", "type": "GEO", "listId": "g"}])
        with self.assertRaises(akamai_client.AkamaiError):
            c.find_list_id_by_name("Ben's IP Blacklist", list_type="IP")


if __name__ == "__main__":
    unittest.main()
