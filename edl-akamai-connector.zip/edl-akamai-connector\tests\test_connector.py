"""Unit tests for the EDL -> Akamai Client List connector core.

Standard library only; no Akamai credentials or network access. The live push
path is exercised with a fake client injected via client_factory.
"""
import ssl
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import akamai_client
import connector
import edl_source
import iocdiff


def _write(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


class TestSSLContext(unittest.TestCase):
    def test_default_verifies(self):
        ctx = akamai_client.build_ssl_context()
        self.assertTrue(ctx.check_hostname)
        self.assertEqual(ctx.verify_mode, ssl.CERT_REQUIRED)

    def test_ca_bundle_keeps_verification_on(self):
        ctx = akamai_client.build_ssl_context(ca_bundle="", verify_ssl=True)
        self.assertTrue(ctx.check_hostname)
        self.assertEqual(ctx.verify_mode, ssl.CERT_REQUIRED)

    def test_bypass_disables_verification(self):
        ctx = akamai_client.build_ssl_context(verify_ssl=False)
        self.assertFalse(ctx.check_hostname)
        self.assertEqual(ctx.verify_mode, ssl.CERT_NONE)


class TestParse(unittest.TestCase):
    def test_keeps_ips_and_cidr_drops_the_rest(self):
        text = (
            "185.12.59.117 #CSTASK0012841 #2026-06-04\n"
            "# a whole-line comment\n"
            "\n"
            "   \n"
            "10.0.0.0/24 #CSTASK0002 #2026-06-04\n"
            "2001:db8::1 #CSTASK0003\n"
            "evil.example.com #CSTASK0004\n"   # domain -> dropped (not a Client List IP)
            "1.2.3.4/path #CSTASK0005\n"        # IP-with-path -> dropped
        )
        self.assertEqual(
            edl_source.parse_ip_lines(text.splitlines()),
            {"185.12.59.117", "10.0.0.0/24", "2001:db8::1"},
        )

    def test_dedupes(self):
        self.assertEqual(edl_source.parse_ip_lines(["1.1.1.1 #x", "1.1.1.1 #y"]), {"1.1.1.1"})


class TestDiff(unittest.TestCase):
    def test_add_and_remove(self):
        d = iocdiff.compute_diff({"a", "b", "c"}, {"b", "c", "d"})
        self.assertEqual(d.add, {"a"})
        self.assertEqual(d.remove, {"d"})
        self.assertTrue(d.changed)

    def test_no_change(self):
        self.assertFalse(iocdiff.compute_diff({"a"}, {"a"}).changed)


class TestFailSafe(unittest.TestCase):
    def test_empty_source_aborts(self):
        ok, _ = iocdiff.fail_safe(set(), {"a", "b"}, 30)
        self.assertFalse(ok)

    def test_empty_current_allowed(self):
        ok, _ = iocdiff.fail_safe({"a"}, set(), 30)
        self.assertTrue(ok)

    def test_excessive_shrink_aborts(self):
        current = {str(i) for i in range(100)}
        desired = {str(i) for i in range(50)}  # 50% shrink > 30% limit
        ok, _ = iocdiff.fail_safe(desired, current, 30)
        self.assertFalse(ok)

    def test_small_shrink_allowed(self):
        current = {str(i) for i in range(100)}
        desired = {str(i) for i in range(80)}  # 20% shrink <= 30% limit
        ok, _ = iocdiff.fail_safe(desired, current, 30)
        self.assertTrue(ok)


class TestLoadEdgerc(unittest.TestCase):
    """The account_switch_key is read from the .edgerc (last line)."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def _edgerc(self, extra=""):
        p = self.tmp / ".edgerc"
        p.write_text("[default]\nhost = akab-x.luna.akamaiapis.net\n"
                     "client_token = akab-ct\nclient_secret = cs=\naccess_token = akab-at\n" + extra,
                     encoding="utf-8")
        return str(p)

    def test_reads_account_switch_key(self):
        creds = akamai_client.load_edgerc(self._edgerc("account_switch_key = 1-ABC:1-XYZ\n"))
        self.assertEqual(creds["account_switch_key"], "1-ABC:1-XYZ")

    def test_accepts_account_key_spelling(self):
        creds = akamai_client.load_edgerc(self._edgerc("account_key = 1-QQ:1-WW\n"))
        self.assertEqual(creds["account_switch_key"], "1-QQ:1-WW")

    def test_accepts_camelcase_accountSwitchKey(self):
        # the exact spelling from the Akamai query param, as some operators write it
        creds = akamai_client.load_edgerc(self._edgerc("accountSwitchKey = 1-ABC:1-XYZ\n"))
        self.assertEqual(creds["account_switch_key"], "1-ABC:1-XYZ")

    def test_no_switch_key_is_empty(self):
        self.assertEqual(akamai_client.load_edgerc(self._edgerc())["account_switch_key"], "")

    def test_client_bakes_in_switch_key(self):
        creds = akamai_client.load_edgerc(self._edgerc("account_switch_key = 1-A:1-B\n"))
        self.assertEqual(akamai_client.ClientListsClient(creds).account_switch_key, "1-A:1-B")


class TestDiscoverTenants(unittest.TestCase):
    """Tenants are the subfolders of Client/, each with its own or the default .edgerc."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.client_dir = self.tmp / "Client"
        _write(self.client_dir / "CustomerA" / ".edgerc", "[default]\nhost=h\n")
        (self.client_dir / "CustomerB").mkdir(parents=True)   # no own .edgerc
        self.default_edgerc = self.tmp / ".edgerc"
        _write(self.default_edgerc, "[default]\nhost=h\n")

    def _cfg(self):
        return {"client_dir": str(self.client_dir), "edgerc": str(self.default_edgerc)}

    def test_each_subfolder_is_a_tenant(self):
        names = [t["name"] for t in connector.discover_tenants(self._cfg())]
        self.assertEqual(names, ["CustomerA", "CustomerB"])

    def test_own_edgerc_is_used_when_present(self):
        t = {x["name"]: x for x in connector.discover_tenants(self._cfg())}["CustomerA"]
        self.assertTrue(t["own_edgerc"])
        self.assertEqual(t["edgerc_path"], str(self.client_dir / "CustomerA" / ".edgerc"))

    def test_falls_back_to_default_edgerc(self):
        t = {x["name"]: x for x in connector.discover_tenants(self._cfg())}["CustomerB"]
        self.assertFalse(t["own_edgerc"])
        self.assertEqual(t["edgerc_path"], str(self.default_edgerc))

    def test_missing_client_dir_yields_no_tenants(self):
        self.assertEqual(connector.discover_tenants({"client_dir": str(self.tmp / "nope")}), [])


class FakeClient:
    """Records calls instead of hitting Akamai."""

    def __init__(self, current=None):
        self._current = set(current or [])
        self.calls = []

    def find_list_id_by_name(self, name, list_type="IP", account_switch_key=""):
        self.calls.append(("resolve", name))
        return "RESOLVED:" + name

    def get_list_items(self, list_id, account_switch_key=""):
        return set(self._current)

    def update_items(self, list_id, add, remove, account_switch_key=""):
        self.calls.append(("update", list_id, set(add), set(remove)))

    def activate(self, list_id, network, comments, account_switch_key=""):
        self.calls.append(("activate", list_id, network))


class TestRun(unittest.TestCase):
    """Folder-driven tenants; fixed list name SingTel_IOC_List; per-folder credential."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.client_dir = self.tmp / "Client"
        _write(self.client_dir / "T1" / ".edgerc", "[default]\nhost=h\n")
        self.central = self.tmp / "central.txt"

    def _cfg(self, ip_lines):
        self.central.write_text(ip_lines, encoding="utf-8")
        return {"client_dir": str(self.client_dir), "edgerc": str(self.tmp / ".edgerc"),
                "central_ioc_source": str(self.central),
                "client_list_name": "SingTel_IOC_List", "safety_shrink_pct": 30}

    def test_offline_shows_diff_no_writes(self):
        results = connector.run(self._cfg("1.1.1.1 #t\n2.2.2.2 #t\n"), offline=True)
        self.assertEqual(results[0]["action"], "offline")
        self.assertEqual((results[0]["desired"], results[0]["add"]), (2, 2))

    def test_live_push_resolves_fixed_name_and_activates(self):
        fake = FakeClient(current={"2.2.2.2", "9.9.9.9"})
        connector.run(self._cfg("1.1.1.1 #t\n2.2.2.2 #t\n"),
                      client_factory=lambda config, edgerc_path: fake)
        self.assertIn(("resolve", "SingTel_IOC_List"), fake.calls)
        self.assertIn(("update", "RESOLVED:SingTel_IOC_List", {"1.1.1.1"}, {"9.9.9.9"}), fake.calls)
        self.assertIn(("activate", "RESOLVED:SingTel_IOC_List", "STAGING"), fake.calls)

    def test_failsafe_aborts_and_does_not_push(self):
        fake = FakeClient(current={f"9.9.9.{i}" for i in range(100)})  # huge shrink vs 1 desired
        results = connector.run(self._cfg("1.1.1.1 #t\n"),
                                client_factory=lambda config, edgerc_path: fake)
        self.assertEqual(results[0]["action"], "aborted")
        self.assertNotIn("update", [c[0] for c in fake.calls])
        self.assertNotIn("activate", [c[0] for c in fake.calls])

    def test_reports_which_credential_was_used(self):
        results = connector.run(self._cfg("1.1.1.1 #t\n"), offline=True)
        self.assertEqual(results[0]["creds"], "own")  # T1 has its own .edgerc


class TestListNameResolution(unittest.TestCase):
    """akamai_client.find_list_id_by_name must exact-match and NEVER create."""

    def _client_returning(self, content):
        c = akamai_client.ClientListsClient(
            {"host": "h", "client_token": "a", "client_secret": "b",
             "access_token": "c", "max_body": 131072})
        c._request = lambda *a, **k: {"content": content}
        return c

    def test_exact_match_returns_id(self):
        c = self._client_returning([
            {"name": "SingTel_IOC_List", "type": "IP", "listId": "999_SGT"},
            {"name": "Other", "type": "IP", "listId": "111"},
        ])
        self.assertEqual(c.find_list_id_by_name("SingTel_IOC_List"), "999_SGT")

    def test_no_match_raises_and_never_creates(self):
        c = self._client_returning([{"name": "Other", "type": "IP", "listId": "111"}])
        with self.assertRaises(akamai_client.AkamaiError):
            c.find_list_id_by_name("SingTel_IOC_List")

    def test_multiple_match_raises(self):
        c = self._client_returning([
            {"name": "Dup", "type": "IP", "listId": "1"},
            {"name": "Dup", "type": "IP", "listId": "2"},
        ])
        with self.assertRaises(akamai_client.AkamaiError):
            c.find_list_id_by_name("Dup")

    def test_wrong_type_is_not_matched(self):
        c = self._client_returning([{"name": "SingTel_IOC_List", "type": "GEO", "listId": "g"}])
        with self.assertRaises(akamai_client.AkamaiError):
            c.find_list_id_by_name("SingTel_IOC_List", list_type="IP")


if __name__ == "__main__":
    unittest.main()
