"""Read and parse the EDL IP blocklist into a set of canonical IP/CIDR strings.

Standard library only. Mirrors edl_core.extract_ioc_value_from_file_line in the
EDL IOC Manager: skip blank lines and whole-line comments, then take the first
whitespace-delimited token of each remaining line (dropping the
``#TICKET #DATE`` audit comment).

Only valid IPv4/IPv6 addresses and CIDR blocks are kept. Anything else -- a
stray domain, an IP-with-path -- is dropped, because an Akamai Client List of
type IP accepts only IP/CIDR values. (Domains/URLs from Block_IOC_URLs.txt have
no Client List home and are out of scope for this connector.)
"""
from __future__ import annotations

import ipaddress
import ssl
import urllib.request
from pathlib import Path
from typing import Iterable, Set


def canonical_ip(token: str):
    """Return the canonical IP/CIDR string, or None if the token is not one."""
    try:
        return str(ipaddress.ip_address(token))
    except ValueError:
        pass
    try:
        return str(ipaddress.ip_network(token, strict=False))
    except ValueError:
        return None


def parse_ip_lines(lines: Iterable[str]) -> Set[str]:
    values: Set[str] = set()
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        canon = canonical_ip(line.split()[0])
        if canon:
            values.add(canon)
    return values


def load_source(source: str, timeout: int = 15, ca_file: str = "") -> str:
    """Load EDL text from a local file path or an http(s) URL.

    A local path is the normal case (the connector runs on the EDL host and
    reads EDL_DATA_DIR directly). A URL uses standard certificate verification;
    pass ``ca_file`` to trust a private CA.
    """
    if source.startswith(("http://", "https://")):
        context = ssl.create_default_context(cafile=ca_file or None)
        request = urllib.request.Request(source, headers={"User-Agent": "edl-akamai-connector"})
        with urllib.request.urlopen(request, timeout=timeout, context=context) as response:  # noqa: S310
            charset = response.headers.get_content_charset() or "utf-8"
            return response.read().decode(charset, "replace")
    return Path(source).read_text(encoding="utf-8")


def read_ip_iocs(source: str, timeout: int = 15, ca_file: str = "") -> Set[str]:
    return parse_ip_lines(load_source(source, timeout=timeout, ca_file=ca_file).splitlines())
