"""Diff and fail-safe logic for syncing an IOC set into a remote list.

Pure standard library so it is fully unit-testable without any Akamai
credentials or network access.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Set, Tuple


@dataclass(frozen=True)
class Diff:
    add: Set[str]
    remove: Set[str]
    desired_count: int
    current_count: int

    @property
    def changed(self) -> bool:
        return bool(self.add or self.remove)


def compute_diff(desired: Set[str], current: Set[str]) -> Diff:
    """What to add and remove to make `current` equal `desired`."""
    desired = set(desired)
    current = set(current)
    return Diff(
        add=desired - current,
        remove=current - desired,
        desired_count=len(desired),
        current_count=len(current),
    )


def fail_safe(desired: Set[str], current: Set[str], shrink_pct: float) -> Tuple[bool, str]:
    """Guard against pushing a broken/empty source that would wipe a blocklist.

    Returns (ok, reason). Aborts when the source produced no entries, or when
    the desired set is smaller than (100 - shrink_pct)% of the current list.
    A push against an empty current list is always allowed (initial load).
    """
    if not desired:
        return False, "source produced 0 entries (refusing to clear the list)"
    if current:
        floor = len(current) * (1.0 - shrink_pct / 100.0)
        if len(desired) < floor:
            return (
                False,
                f"desired {len(desired)} entries is below the safety floor "
                f"{floor:.0f} ({shrink_pct:g}% max shrink of current {len(current)})",
            )
    return True, "ok"
