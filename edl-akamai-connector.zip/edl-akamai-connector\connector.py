"""EDL -> Akamai Client List connector (IP-only, enforce mode).

Reads the EDL IOC Manager's Block_IOC_IPs.txt and, per tenant, pushes the IPs
into an Akamai Client List so App & API Protector can enforce them with a DENY.
Domains/URLs (Block_IOC_URLs.txt) are out of scope: a Client List of type IP
holds only IP/CIDR values.

Akamai has no EDL-style pull, so this connector owns the read/diff/push loop.
Run it on a schedule (Windows Task Scheduler) on the EDL host. Standard library
only; the Akamai calls use the hand-rolled EdgeGrid signer.

Usage:
  python connector.py --config config.json                 # push + activate
  python connector.py --config config.json --dry-run       # read-only: show diff
  python connector.py --config config.json --offline       # no Akamai calls at all
  python connector.py --config config.json --tenant NAME   # limit to one tenant

Exit code 0 = all lists ok; 1 = any tenant aborted (fail-safe) or errored.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Callable, List, Optional

import edl_source
import iocdiff

APP_DIR = Path(__file__).resolve().parent


def _resolve_current(client, spec: dict, offline: bool):
    """Get the current Client List contents, or an offline stand-in."""
    if offline or client is None:
        current_file = spec.get("current_file") or ""
        if current_file:
            lines = Path(current_file).read_text(encoding="utf-8").splitlines()
            return edl_source.parse_ip_lines(lines), "current_file"
        return set(), "assumed-empty"
    return client.get_list_items(spec["client_list_id"], spec.get("account_switch_key", "")), "akamai"


def run(config: dict, dry_run: bool = False, offline: bool = False,
        only_tenant: Optional[str] = None, client_factory: Optional[Callable] = None) -> List[dict]:
    """Process every configured tenant. Returns one result dict per tenant."""
    timeout = int(config.get("edl_fetch_timeout", 15))
    ca_file = config.get("edl_ca_file", "")
    default_network = config.get("activation_network", "STAGING")
    comments = config.get("activation_comment", "EDL IOC sync")

    client = None
    if not offline:
        factory = client_factory or _default_client_factory
        client = factory(config)

    central_source = config.get("central_ioc_source", "")
    results: List[dict] = []
    for tenant in config.get("tenants", []):
        name = tenant.get("name")
        if only_tenant and name != only_tenant:
            continue
        result = {"tenant": name}
        # A tenant participates unless it explicitly opts out with enabled=false.
        if not tenant.get("enabled", True):
            result.update(action="skipped", reason="not subscribed (enabled=false)")
            results.append(result)
            continue
        ask = tenant.get("account_switch_key", "")
        spec = {**tenant, "account_switch_key": ask}
        # Each tenant consumes the central IOC list by default; a tenant may
        # override with its own edl_ip_path / edl_ip_url.
        source = spec.get("edl_ip_path") or spec.get("edl_ip_url") or central_source
        result["source"] = source
        try:
            if not source:
                raise ValueError("no IOC source: set top-level 'central_ioc_source' "
                                 "or a per-tenant 'edl_ip_path'/'edl_ip_url'")
            # Resolve the target list. Prefer an explicit id; otherwise look up an
            # EXISTING list by name (never creates one). Only needed for live/dry-run.
            if not offline:
                list_id = spec.get("client_list_id", "")
                if not list_id:
                    list_name = spec.get("client_list_name", "")
                    if not list_name:
                        raise ValueError("tenant needs 'client_list_id' or 'client_list_name'")
                    list_id = client.find_list_id_by_name(list_name, account_switch_key=ask)
                    spec = {**spec, "client_list_id": list_id}
                result["client_list_id"] = list_id
            desired = edl_source.read_ip_iocs(source, timeout=timeout, ca_file=ca_file)
            current, current_from = _resolve_current(client, spec, offline)
            ok, reason = iocdiff.fail_safe(desired, current, float(spec.get("safety_shrink_pct", 30)))
            diff = iocdiff.compute_diff(desired, current)
            result.update(desired=len(desired), current=len(current), current_from=current_from,
                          add=len(diff.add), remove=len(diff.remove))
            if not ok:
                result.update(action="aborted", reason=reason)
            elif offline or dry_run:
                result.update(action=("offline" if offline else "dry-run"), reason="no writes")
            elif not diff.changed:
                result.update(action="unchanged", reason="already in sync")
            else:
                list_id = spec["client_list_id"]
                client.update_items(list_id, diff.add, diff.remove, ask)
                client.activate(list_id, spec.get("activation_network", default_network), comments, ask)
                result.update(action="pushed", reason="applied")
        except Exception as exc:  # keep going for other tenants; report this one
            result.update(action="error", reason=f"{type(exc).__name__}: {exc}")
        results.append(result)
    return results


def _default_client_factory(config: dict):
    import akamai_client
    # Default: a `.edgerc` sitting next to the script (drop-in, zero config).
    # Override with "edgerc" in config.json for any other location.
    edgerc = config.get("edgerc") or str(APP_DIR / ".edgerc")
    creds = akamai_client.load_edgerc(edgerc, config.get("edgerc_section", "default"))
    return akamai_client.ClientListsClient(
        creds,
        ca_bundle=config.get("akamai_ca_bundle", ""),
        verify_ssl=config.get("akamai_verify_ssl", True),
    )


def _print(results: List[dict]) -> bool:
    all_ok = True
    for r in results:
        flag = {"pushed": "OK", "unchanged": "OK", "dry-run": "--", "offline": "--",
                "skipped": "--", "aborted": "!!", "error": "XX"}.get(r["action"], "??")
        if r["action"] in ("aborted", "error"):
            all_ok = False
        counts = (f"desired={r.get('desired', '?')} current={r.get('current', '?')}"
                  f" (+{r.get('add', '?')}/-{r.get('remove', '?')})") if "desired" in r else ""
        print(f"[{flag}] {str(r['tenant']):14} {r['action']:9} {counts}  {r.get('reason', '')}")
    return all_ok


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Push EDL IP IOCs into Akamai Client Lists.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--dry-run", action="store_true", help="read-only: show the diff, no writes")
    parser.add_argument("--offline", action="store_true", help="no Akamai calls at all (local check)")
    parser.add_argument("--tenant", default=None, help="limit to one tenant by name")
    parser.add_argument("--insecure", action="store_true",
                        help="disable Akamai TLS verification for this run (last resort; prefer akamai_ca_bundle)")
    args = parser.parse_args(argv)

    # utf-8-sig tolerates a byte-order mark, which Windows editors often add.
    config = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    if args.insecure:
        config["akamai_verify_ssl"] = False
    results = run(config, dry_run=args.dry_run, offline=args.offline, only_tenant=args.tenant)
    all_ok = _print(results)
    skipped = sum(1 for r in results if r["action"] == "skipped")
    processed = len(results) - skipped
    print(f"\n{processed} tenant list(s) processed, {skipped} not subscribed; "
          f"{'all OK' if all_ok else 'FAILURES present'}.")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
