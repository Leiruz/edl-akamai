"""EDL -> Akamai Client List connector (IP-only, enforce mode).

Reads the EDL IOC Manager's Block_IOC_IPs.txt and, per tenant, pushes the IPs
into an Akamai Client List so App & API Protector can enforce them with a DENY.
Domains/URLs (Block_IOC_URLs.txt) are out of scope: a Client List of type IP
holds only IP/CIDR values.

Akamai has no EDL-style pull, so this connector owns the read/diff/push loop.
Run it on a schedule (Windows Task Scheduler) on the EDL host. Standard library
only; the Akamai calls use the hand-rolled EdgeGrid signer.

Tenants are discovered from the subfolders of Client/. Each tenant uses its own
Client/<tenant>/.edgerc (a full credential whose last line carries the
account_switch_key) or, if absent, the default .edgerc beside Client/. Every
tenant targets the Client List named SingTel_IOC_List, which must already exist
(this tool never creates lists).

Usage:
  python connector.py --config config.json                 # push + activate
  python connector.py --config config.json --dry-run       # read-only: show diff
  python connector.py --config config.json --offline       # no Akamai calls at all
  python connector.py --config config.json --tenant NAME   # limit to one folder

Exit code 0 = all lists ok; 1 = any tenant aborted (fail-safe) or errored.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Callable, List, Optional

import edl_source
import iocdiff

APP_DIR = Path(__file__).resolve().parent


def discover_tenants(config: dict) -> List[dict]:
    """Tenants are the subfolders of Client/. Each tenant uses its own
    Client/<tenant>/.edgerc if present, otherwise the default .edgerc that sits
    beside the Client/ folder. To opt a tenant out, remove or rename its folder.
    """
    cdir = config.get("client_dir")
    client_dir = Path(cdir) if cdir else (APP_DIR / "Client")
    if not client_dir.is_dir() and (APP_DIR / "client").is_dir():
        client_dir = APP_DIR / "client"          # tolerate a lowercase folder name
    default_edgerc = config.get("edgerc") or str(APP_DIR / ".edgerc")

    tenants: List[dict] = []
    if not client_dir.is_dir():
        return tenants
    for sub in sorted(p for p in client_dir.iterdir() if p.is_dir()):
        own = sub / ".edgerc"
        tenants.append({
            "name": sub.name,
            "edgerc_path": str(own) if own.is_file() else default_edgerc,
            "own_edgerc": own.is_file(),
        })
    return tenants


def run(config: dict, dry_run: bool = False, offline: bool = False,
        only_tenant: Optional[str] = None, client_factory: Optional[Callable] = None) -> List[dict]:
    """Process every tenant discovered under Client/. One result dict per tenant."""
    timeout = int(config.get("edl_fetch_timeout", 15))
    ca_file = config.get("edl_ca_file", "")
    network = config.get("activation_network", "STAGING")
    comments = config.get("activation_comment", "EDL IOC sync")
    list_name = config.get("client_list_name", "SingTel_IOC_List")
    source = config.get("central_ioc_source", "")
    shrink = float(config.get("safety_shrink_pct", 30))
    factory = client_factory or _default_client_factory

    results: List[dict] = []
    for tenant in discover_tenants(config):
        name = tenant["name"]
        if only_tenant and name != only_tenant:
            continue
        result = {"tenant": name, "creds": ("own" if tenant["own_edgerc"] else "default")}
        try:
            if not source:
                raise ValueError("no IOC source: set top-level 'central_ioc_source'")
            desired = edl_source.read_ip_iocs(source, timeout=timeout, ca_file=ca_file)
            if offline:
                current, current_from, list_id = set(), "assumed-empty", ""
            else:
                # The credential carries this tenant's account_switch_key, so every
                # call operates on the right account. The target list is fixed and
                # looked up by name; it is never created.
                client = factory(config, tenant["edgerc_path"])
                list_id = client.find_list_id_by_name(list_name)
                result["client_list_id"] = list_id
                current, current_from = client.get_list_items(list_id), "akamai"
            ok, reason = iocdiff.fail_safe(desired, current, shrink)
            diff = iocdiff.compute_diff(desired, current)
            result.update(desired=len(desired), current=len(current), current_from=current_from,
                          add=len(diff.add), remove=len(diff.remove))
            if not ok:
                result.update(action="aborted", reason=reason)
            elif offline or dry_run:
                result.update(action=("offline" if offline else "dry-run"), reason="no writes")
            elif not diff.changed:
                result.update(action="unchanged", reason="already in sync")
            else:
                client.update_items(list_id, diff.add, diff.remove)
                client.activate(list_id, network, comments)
                result.update(action="pushed", reason="applied")
        except Exception as exc:  # isolate: one bad tenant must not stop the others
            result.update(action="error", reason=f"{type(exc).__name__}: {exc}")
        results.append(result)
    return results


def _default_client_factory(config: dict, edgerc_path: str):
    import akamai_client
    creds = akamai_client.load_edgerc(edgerc_path, config.get("edgerc_section", "default"))
    return akamai_client.ClientListsClient(
        creds,
        ca_bundle=config.get("akamai_ca_bundle", ""),
        verify_ssl=config.get("akamai_verify_ssl", True),
    )


def _print(results: List[dict]) -> bool:
    all_ok = True
    for r in results:
        flag = {"pushed": "OK", "unchanged": "OK", "dry-run": "--", "offline": "--",
                "skipped": "--", "aborted": "!!", "error": "XX"}.get(r["action"], "??")
        if r["action"] in ("aborted", "error"):
            all_ok = False
        counts = (f"desired={r.get('desired', '?')} current={r.get('current', '?')}"
                  f" (+{r.get('add', '?')}/-{r.get('remove', '?')})") if "desired" in r else ""
        print(f"[{flag}] {str(r['tenant']):14} {r['action']:9} {counts}  {r.get('reason', '')}")
    return all_ok


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Push EDL IP IOCs into Akamai Client Lists.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--dry-run", action="store_true", help="read-only: show the diff, no writes")
    parser.add_argument("--offline", action="store_true", help="no Akamai calls at all (local check)")
    parser.add_argument("--tenant", default=None, help="limit to one tenant by name")
    parser.add_argument("--insecure", action="store_true",
                        help="disable Akamai TLS verification for this run (last resort; prefer akamai_ca_bundle)")
    args = parser.parse_args(argv)

    # utf-8-sig tolerates a byte-order mark, which Windows editors often add.
    config = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    if args.insecure:
        config["akamai_verify_ssl"] = False
    results = run(config, dry_run=args.dry_run, offline=args.offline, only_tenant=args.tenant)
    if not results:
        print("No tenants found. Expected subfolders under 'Client/' next to connector.py "
              "(or set 'client_dir' in the config).")
        return 1
    all_ok = _print(results)
    print(f"\n{len(results)} tenant(s) processed from Client/; "
          f"{'all OK' if all_ok else 'FAILURES present'}.")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
