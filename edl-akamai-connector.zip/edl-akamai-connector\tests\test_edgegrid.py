"""Verify the EdgeGrid signer against Akamai's official reference test vectors.

Vectors are the fixed inputs from akamai/AkamaiOPEN-edgegrid-python
(test/testdata.json): a shared credential set with a frozen timestamp and
nonce, and the exact expected Authorization header per case.
"""
import unittest

import edgegrid_auth

HOST = "akaa-baseurl-xxxxxxxxxxx-xxxxxxxxxxxxx.luna.akamaiapis.net"
BASE = f"https://{HOST}"
CREDS = dict(
    client_token="akab-client-token-xxx-xxxxxxxxxxxxxxxx",
    access_token="akab-access-token-xxx-xxxxxxxxxxxxxxxx",
    client_secret="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=",
)
TS = "20140321T19:34:21+0000"
NONCE = "nonce-xx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
MAX_BODY = 2048


def _expected(sig):
    return (
        "EG1-HMAC-SHA256 "
        "client_token=akab-client-token-xxx-xxxxxxxxxxxxxxxx;"
        "access_token=akab-access-token-xxx-xxxxxxxxxxxxxxxx;"
        f"timestamp={TS};nonce={NONCE};signature={sig}"
    )


class EdgeGridVectorTests(unittest.TestCase):
    def _sign(self, method, path, **kw):
        return edgegrid_auth.sign(
            method, BASE + path, timestamp=TS, nonce=NONCE, max_body=MAX_BODY,
            **CREDS, **kw,
        )

    def test_simple_get(self):
        self.assertEqual(
            self._sign("GET", "/"),
            _expected("tL+y4hxyHxgWVD30X3pWnGKHcPzmrIF+LThiAOhMxYU="),
        )

    def test_post_inside_limit(self):
        self.assertEqual(
            self._sign("POST", "/testapi/v1/t3",
                       body="datadatadatadatadatadatadatadata"),
            _expected("hXm4iCxtpN22m4cbZb4lVLW5rhX8Ca82vCFqXzSTPe4="),
        )

    def test_get_with_querystring(self):
        self.assertEqual(
            self._sign("GET", "/testapi/v1/t1?p1=1&p2=2"),
            _expected("hKDH1UlnQySSHjvIcZpDMbQHihTQ0XyVAKZaApabdeA="),
        )

    def test_header_signing(self):
        self.assertEqual(
            self._sign("GET", "/testapi/v1/t4",
                       headers={"X-Test1": "test-simple-header"},
                       headers_to_sign=["X-Test1", "X-Test2", "X-Test3"]),
            _expected("8F9AybcRw+PLxnvT+H0JRkjROrrUgsxJTnRXMzqvcwY="),
        )

    def test_post_empty_body(self):
        self.assertEqual(
            self._sign("POST", "/testapi/v1/t6", body=""),
            _expected("1gEDxeQGD5GovIkJJGcBaKnZ+VaPtrc4qBUHixjsPCQ="),
        )

    def test_put_body_not_hashed(self):
        self.assertEqual(
            self._sign("PUT", "/testapi/v1/t6", body="P" * 31),
            _expected("GNBWEYSEWOLtu+7dD52da2C39aX/Jchpon3K/AmBqBU="),
        )


if __name__ == "__main__":
    unittest.main()
