"""Akamai EdgeGrid EG1-HMAC-SHA256 request signing.

Standard library only. Verified against the official
akamai/AkamaiOPEN-edgegrid-python test vectors (see tests/test_edgegrid.py).

The data-to-sign is seven TAB-joined fields:
    method, scheme, host, relative_url, canonical_headers, content_hash, auth_header
The content hash is present only for POST requests with a body; for every
other method (including PUT/PATCH with a body) it is an empty field.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import re
import uuid
from datetime import datetime, timezone
from urllib.parse import urlsplit

DEFAULT_MAX_BODY = 131072
_WHITESPACE = re.compile(r"\s+")


def _b64_hmac_sha256(key, msg) -> str:
    if isinstance(key, str):
        key = key.encode("utf-8")
    if isinstance(msg, str):
        msg = msg.encode("utf-8")
    return base64.b64encode(hmac.new(key, msg, hashlib.sha256).digest()).decode("ascii")


def _b64_sha256(data: bytes) -> str:
    return base64.b64encode(hashlib.sha256(data).digest()).decode("ascii")


def eg_timestamp() -> str:
    """Current UTC time in EdgeGrid's format, e.g. 20140321T19:34:21+0000."""
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H:%M:%S+0000")


def new_nonce() -> str:
    return str(uuid.uuid4())


def _canonicalize_headers(headers, headers_to_sign) -> str:
    if not headers_to_sign:
        return ""
    lower = {str(k).lower(): v for k, v in (headers or {}).items()}
    parts = []
    for name in headers_to_sign:
        value = lower.get(str(name).lower())
        if value is None:
            continue
        parts.append(f"{str(name).lower()}:{_WHITESPACE.sub(' ', str(value).strip())}")
    return "\t".join(parts)


def _content_hash(method: str, body: bytes, max_body: int) -> str:
    if method != "POST" or not body:
        return ""
    return _b64_sha256(body[:max_body])


def sign(method, url, *, client_token, client_secret, access_token,
         headers=None, headers_to_sign=None, body=b"",
         timestamp=None, nonce=None, max_body=DEFAULT_MAX_BODY) -> str:
    """Return the value for the ``Authorization`` request header.

    ``timestamp`` and ``nonce`` are injectable for testing; in normal use they
    are generated. ``body`` may be str or bytes.
    """
    if isinstance(body, str):
        body = body.encode("utf-8")
    method = method.upper()
    ts = timestamp or eg_timestamp()
    nc = nonce or new_nonce()

    parts = urlsplit(url)
    scheme = parts.scheme or "https"
    host = parts.netloc
    relative_url = parts.path or "/"
    if parts.query:
        relative_url += "?" + parts.query

    auth_fields = (
        f"client_token={client_token};"
        f"access_token={access_token};"
        f"timestamp={ts};"
        f"nonce={nc}"
    )
    unsigned = f"EG1-HMAC-SHA256 {auth_fields};"

    data_to_sign = "\t".join([
        method,
        scheme,
        host,
        relative_url,
        _canonicalize_headers(headers, headers_to_sign),
        _content_hash(method, body, max_body),
        unsigned,
    ])

    signing_key = _b64_hmac_sha256(client_secret, ts)
    signature = _b64_hmac_sha256(signing_key, data_to_sign)
    return f"{unsigned}signature={signature}"
